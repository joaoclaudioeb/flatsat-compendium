RDEPENDS:${PN}:remove = "\
    dnndk \
"
